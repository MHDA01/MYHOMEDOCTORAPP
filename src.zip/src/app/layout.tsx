
'use client';
import './globals.css';
import { Toaster } from "@/components/ui/toaster"
import { useEffect } from 'react';

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker
        .register('/sw.js?v=4')
        .then((registration) => registration.update())
        .catch(() => undefined);
    }
  }, []);

  return (
    <html lang="es" suppressHydrationWarning>
      <head>
        <title>MiDoctorDeCasaApp</title>
        <meta name="description" content="Tu asistente personal de gestión de salud." />
        <link rel="canonical" href="https://www.myhomedoctorapp.com" />
        <link rel="manifest" href="/manifest.webmanifest" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
        <meta name="application-name" content="MiDoctorDeCasaApp" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="MiDoctorDeCasaApp" />
        <meta name="format-detection" content="telephone=no" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="theme-color" content="#3B82F6" />
        <link rel="apple-touch-icon" href="/LOGO_1.png?v=5" />
      </head>
      <body className="font-body antialiased">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
