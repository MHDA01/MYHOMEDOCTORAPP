fatal: invalid object name 'e0affd'.
